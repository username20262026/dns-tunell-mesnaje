package com.dnstunnel;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

/**
 * Lógica DNS pura, sin dependencias de Android UI.
 */
public class DnsClient {

    private static final String SERVER_IP  = "45.228.139.148";
    private static final int    DNS_PORT   = 53;
    public  static final String DOMAIN     = ".t.nnxsw-proyect.date";
    public  static final int    CHUNK_SIZE = 20;

    private static final String B32 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";

    // ─── Envío ───────────────────────────────────────────────────────────────

    /** Envía un mensaje al servidor con userId como remitente.
     *  Formato en el servidor: uid.seq.total.payload → reenvía a destino
     *  El texto real enviado es "to:dest:texto" para que server.py lo rutee.
     */
    public static boolean sendMessage(String fromUser, String toUser, String text,
                                      SendProgress cb) throws Exception {
        String payload = "to:" + toUser + ":" + text;
        String encoded = encodeB32(payload);
        int total = (int) Math.ceil((double) encoded.length() / CHUNK_SIZE);
        int ok = 0;
        for (int i = 0; i < total; i++) {
            int    s     = i * CHUNK_SIZE;
            int    e     = Math.min(s + CHUNK_SIZE, encoded.length());
            String chunk = encoded.substring(s, e);
            String seq   = String.format("%03d", i + 1);
            String tot   = String.format("%03d", total);
            String fqdn  = fromUser + "." + seq + "." + tot + "." + chunk + DOMAIN;
            if (rawQuery(fqdn, false) != null) ok++;
            if (cb != null) cb.onProgress(i + 1, total);
            Thread.sleep(300);
        }
        return ok == total;
    }

    // ─── Poll ────────────────────────────────────────────────────────────────

    public static class PollResult {
        public String from;
        public String text;
    }

    /** Hace poll al servidor. Devuelve null si no hay mensaje o error. */
    public static PollResult poll(String userId) {
        try {
            String fqdn = "poll." + userId + DOMAIN;
            byte[] buf  = rawQuery(fqdn, true);
            if (buf == null) return null;
            String payload = parseTxt(buf);
            if (payload == null || payload.equals("empty")) return null;
            String decoded = decodeB32(payload);
            if (decoded == null || decoded.isEmpty()) return null;
            PollResult r = new PollResult();
            int sep = decoded.indexOf('|');
            if (sep > 0) {
                r.from = decoded.substring(0, sep);
                r.text = decoded.substring(sep + 1);
            } else {
                r.from = "server";
                r.text = decoded;
            }
            return r;
        } catch (Exception e) {
            return null;
        }
    }

    // ─── DNS raw ─────────────────────────────────────────────────────────────

    static byte[] rawQuery(String fqdn, boolean isTxt) {
        try {
            DatagramSocket sock = new DatagramSocket();
            sock.setSoTimeout(3000);
            byte[] q   = buildQuery(fqdn, isTxt);
            sock.send(new DatagramPacket(q, q.length,
                InetAddress.getByName(SERVER_IP), DNS_PORT));
            byte[] buf  = new byte[512];
            DatagramPacket resp = new DatagramPacket(buf, buf.length);
            sock.receive(resp);
            sock.close();
            byte[] out = new byte[resp.getLength()];
            System.arraycopy(buf, 0, out, 0, resp.getLength());
            return out;
        } catch (Exception e) {
            return null;
        }
    }

    private static byte[] buildQuery(String fqdn, boolean isTxt) {
        java.util.List<Byte> q = new java.util.ArrayList<>();
        q.add((byte)0x00); q.add((byte)0x01);
        q.add((byte)0x01); q.add((byte)0x00);
        q.add((byte)0x00); q.add((byte)0x01);
        q.add((byte)0x00); q.add((byte)0x00);
        q.add((byte)0x00); q.add((byte)0x00);
        q.add((byte)0x00); q.add((byte)0x00);
        for (String label : fqdn.split("\\.")) {
            q.add((byte) label.length());
            for (char c : label.toCharArray()) q.add((byte) c);
        }
        q.add((byte)0x00);
        q.add((byte)0x00); q.add(isTxt ? (byte)0x10 : (byte)0x01);
        q.add((byte)0x00); q.add((byte)0x01);
        byte[] out = new byte[q.size()];
        for (int i = 0; i < q.size(); i++) out[i] = q.get(i);
        return out;
    }

    private static String parseTxt(byte[] buf) {
        try {
            if (((buf[6] & 0xFF) << 8 | (buf[7] & 0xFF)) == 0) return null;
            int pos = 12;
            // Saltar QNAME
            while (pos < buf.length) {
                int len = buf[pos] & 0xFF;
                if (len == 0) { pos++; break; }
                if ((len & 0xC0) == 0xC0) { pos += 2; break; }
                pos += len + 1;
            }
            pos += 4; // QTYPE + QCLASS
            // Saltar NAME de la respuesta
            if ((buf[pos] & 0xC0) == 0xC0) pos += 2;
            else { while (pos < buf.length && buf[pos] != 0) pos += (buf[pos] & 0xFF) + 1; pos++; }
            pos += 2; // TYPE
            pos += 2; // CLASS
            pos += 4; // TTL
            int rdLen = (buf[pos] & 0xFF) << 8 | (buf[pos+1] & 0xFF); pos += 2;
            // TXT RDATA: concatenar todos los string-lengths
            int end = pos + rdLen;
            StringBuilder sb = new StringBuilder();
            while (pos < end) {
                int tLen = buf[pos] & 0xFF; pos++;
                sb.append(new String(buf, pos, tLen, "UTF-8"));
                pos += tLen;
            }
            return sb.toString();
        } catch (Exception e) { return null; }
    }

    // ─── Base32 ──────────────────────────────────────────────────────────────

    public static String encodeB32(String text) {
        byte[] bytes = text.getBytes(java.nio.charset.StandardCharsets.UTF_8);
        StringBuilder sb = new StringBuilder();
        int buf = 0, bits = 0;
        for (byte b : bytes) {
            buf = (buf << 8) | (b & 0xFF); bits += 8;
            while (bits >= 5) { bits -= 5; sb.append(B32.charAt((buf >> bits) & 31)); }
        }
        if (bits > 0) sb.append(B32.charAt((buf << (5 - bits)) & 31));
        return sb.toString().toLowerCase();
    }

    public static String decodeB32(String payload) {
        try {
            String[] parts = payload.split("\\|");
            if (parts.length < 2) return null;
            int total = Integer.parseInt(parts[0].trim());
            StringBuilder enc = new StringBuilder();
            for (int i = 1; i <= total && i < parts.length; i++) enc.append(parts[i].trim());
            String b32 = enc.toString().toUpperCase();
            // Decodificar a bytes (correcto para UTF-8 multibyte)
            java.util.List<Byte> bytes = new java.util.ArrayList<>();
            int buf = 0, bits = 0;
            for (char c : b32.toCharArray()) {
                int val = B32.indexOf(c);
                if (val < 0) continue;
                buf = (buf << 5) | val; bits += 5;
                if (bits >= 8) { bits -= 8; bytes.add((byte)((buf >> bits) & 0xFF)); }
            }
            byte[] raw = new byte[bytes.size()];
            for (int i = 0; i < bytes.size(); i++) raw[i] = bytes.get(i);
            return new String(raw, java.nio.charset.StandardCharsets.UTF_8);
        } catch (Exception e) { return null; }
    }

    public interface SendProgress {
        void onProgress(int done, int total);
    }
}
