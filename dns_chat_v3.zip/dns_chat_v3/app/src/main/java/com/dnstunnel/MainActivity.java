package com.dnstunnel;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    // Referencia estática para que el poller entregue mensajes a la ChatActivity abierta
    public static String       activeChatPeer     = null;
    public static ChatActivity activeChatActivity = null;

    private String myId;

    private LinearLayout chatListContainer;
    private ScrollView   scrollView;
    private EditText     etSearch;
    private TextView     tvStatus;

    private final ExecutorService executor = Executors.newCachedThreadPool();
    private final Handler         handler  = new Handler(Looper.getMainLooper());
    private Runnable pollRunnable;

    // ─── Lifecycle ────────────────────────────────────────────────────────────

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildLayout();
        askUserId();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshList(null);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (pollRunnable != null) handler.removeCallbacks(pollRunnable);
        executor.shutdownNow();
    }

    // ─── Layout ───────────────────────────────────────────────────────────────

    private void buildLayout() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF0D1117);

        // Status bar
        tvStatus = new TextView(this);
        tvStatus.setText("● Conectando...");
        tvStatus.setTextColor(0xFF8888aa);
        tvStatus.setTextSize(12f);
        tvStatus.setPadding(16, 10, 16, 10);
        root.addView(tvStatus);

        // Buscador
        etSearch = new EditText(this);
        etSearch.setHint("🔍  Buscar o nuevo chat...");
        etSearch.setHintTextColor(0xFF555577);
        etSearch.setTextColor(Color.WHITE);
        etSearch.setBackgroundColor(0xFF21262D);
        etSearch.setPadding(20, 14, 20, 14);
        LinearLayout.LayoutParams searchParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT);
        searchParams.setMargins(12, 8, 12, 8);
        etSearch.setLayoutParams(searchParams);
        root.addView(etSearch);

        // Lista de chats
        scrollView = new ScrollView(this);
        LinearLayout.LayoutParams scrollParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f);
        scrollView.setLayoutParams(scrollParams);
        chatListContainer = new LinearLayout(this);
        chatListContainer.setOrientation(LinearLayout.VERTICAL);
        scrollView.addView(chatListContainer);
        root.addView(scrollView);

        setContentView(root);

        // Listener del buscador
        etSearch.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            public void onTextChanged(CharSequence s, int st, int b, int c) {
                refreshList(s.toString().trim());
            }
            public void afterTextChanged(Editable s) {}
        });

        // Enter en el buscador → abrir chat nuevo con ese usuario
        etSearch.setOnEditorActionListener((v, actionId, event) -> {
            String query = etSearch.getText().toString().trim()
                           .toLowerCase().replaceAll("[^a-z0-9_]", "");
            if (!query.isEmpty() && myId != null) {
                etSearch.setText("");
                openChat(query);
            }
            return true;
        });
    }

    // ─── Login ────────────────────────────────────────────────────────────────

    private void askUserId() {
        EditText input = new EditText(this);
        input.setHint("ej: juan, alice, usr1");
        input.setSingleLine(true);

        new AlertDialog.Builder(this)
            .setTitle("¿Cuál es tu usuario?")
            .setMessage("Ingresá tu nombre para conectarte")
            .setView(input)
            .setCancelable(false)
            .setPositiveButton("Conectar", (dialog, which) -> {
                String typed = input.getText().toString().trim()
                               .toLowerCase().replaceAll("[^a-z0-9_]", "");
                if (typed.isEmpty()) typed = "usr1";
                myId = typed;
                setTitle("DNS Chat — " + myId);
                startPolling();
                refreshList(null);
            })
            .show();
    }

    // ─── Lista de chats ───────────────────────────────────────────────────────

    private void refreshList(String query) {
        handler.post(() -> {
            chatListContainer.removeAllViews();
            List<ChatStore.Chat> chats = (query == null || query.isEmpty())
                ? ChatStore.get().getChats()
                : ChatStore.get().search(query);

            if (chats.isEmpty() && query != null && !query.isEmpty()) {
                // Mostrar opción de iniciar chat nuevo
                addNewChatRow(query);
            } else {
                for (ChatStore.Chat c : chats) addChatRow(c);
            }
        });
    }

    private void addChatRow(ChatStore.Chat chat) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setBackgroundColor(0xFF161B22);
        row.setPadding(16, 16, 16, 16);

        LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT);
        rowParams.setMargins(0, 0, 0, 1);
        row.setLayoutParams(rowParams);

        // Avatar círculo
        TextView avatar = new TextView(this);
        avatar.setText(chat.peerId.substring(0, 1).toUpperCase());
        avatar.setTextColor(Color.WHITE);
        avatar.setTextSize(18f);
        avatar.setTypeface(null, Typeface.BOLD);
        avatar.setGravity(Gravity.CENTER);
        avatar.setBackgroundColor(avatarColor(chat.peerId));
        LinearLayout.LayoutParams avParams = new LinearLayout.LayoutParams(52, 52);
        avParams.rightMargin = 16;
        avParams.gravity = Gravity.CENTER_VERTICAL;
        avatar.setLayoutParams(avParams);
        row.addView(avatar);

        // Nombre + último mensaje
        LinearLayout textCol = new LinearLayout(this);
        textCol.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams tcParams = new LinearLayout.LayoutParams(0,
            LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        textCol.setLayoutParams(tcParams);

        TextView tvName = new TextView(this);
        tvName.setText(chat.peerId);
        tvName.setTextColor(Color.WHITE);
        tvName.setTextSize(16f);
        tvName.setTypeface(null, chat.unread > 0 ? Typeface.BOLD : Typeface.NORMAL);
        textCol.addView(tvName);

        if (!chat.lastText().isEmpty()) {
            TextView tvLast = new TextView(this);
            String last = chat.lastText();
            if (last.length() > 40) last = last.substring(0, 40) + "…";
            tvLast.setText(last);
            tvLast.setTextColor(0xFF8888aa);
            tvLast.setTextSize(13f);
            textCol.addView(tvLast);
        }
        row.addView(textCol);

        // Badge de no leídos
        if (chat.unread > 0) {
            TextView badge = new TextView(this);
            badge.setText(String.valueOf(chat.unread));
            badge.setTextColor(Color.WHITE);
            badge.setTextSize(12f);
            badge.setGravity(Gravity.CENTER);
            badge.setBackgroundColor(0xFF238636);
            badge.setPadding(10, 4, 10, 4);
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
            bp.gravity = Gravity.CENTER_VERTICAL;
            badge.setLayoutParams(bp);
            row.addView(badge);
        }

        row.setOnClickListener(v -> openChat(chat.peerId));
        chatListContainer.addView(row);
    }

    private void addNewChatRow(String query) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setBackgroundColor(0xFF161B22);
        row.setPadding(16, 20, 16, 20);

        TextView tv = new TextView(this);
        tv.setText("💬  Iniciar chat con \"" + query + "\"");
        tv.setTextColor(0xFF58A6FF);
        tv.setTextSize(15f);
        row.addView(tv);

        row.setOnClickListener(v -> {
            String clean = query.toLowerCase().replaceAll("[^a-z0-9_]", "");
            if (!clean.isEmpty()) {
                etSearch.setText("");
                openChat(clean);
            }
        });
        chatListContainer.addView(row);
    }

    private void openChat(String peerId) {
        ChatStore.get().getOrCreate(peerId);
        Intent intent = new Intent(this, ChatActivity.class);
        intent.putExtra(ChatActivity.EXTRA_MY_ID,   myId);
        intent.putExtra(ChatActivity.EXTRA_PEER_ID, peerId);
        startActivity(intent);
    }

    // ─── Polling global ───────────────────────────────────────────────────────

    private void startPolling() {
        pollRunnable = new Runnable() {
            @Override public void run() {
                executor.execute(() -> doPoll());
                handler.postDelayed(this, 5000);
            }
        };
        handler.postDelayed(pollRunnable, 2000);
    }

    private void doPoll() {
        if (myId == null) return;
        DnsClient.PollResult result = DnsClient.poll(myId);

        handler.post(() -> {
            tvStatus.setText(result != null || true
                ? "● Online — " + myId : "● Sin conexión");
            tvStatus.setTextColor(0xFF44cc77);
        });

        if (result == null) return;

        Message msg = new Message(result.text, Message.TYPE_RECEIVED);
        String  peer = result.from;

        ChatStore.get().addMessage(peer, msg);

        // Si el chat con ese peer está abierto, entregarlo directo
        if (peer.equals(activeChatPeer) && activeChatActivity != null) {
            activeChatActivity.onNewMessage(msg);
            ChatStore.get().clearUnread(peer);
        }

        // Actualizar lista
        refreshList(null);
    }

    // ─── Helpers ──────────────────────────────────────────────────────────────

    private int avatarColor(String id) {
        int[] colors = {0xFF1F6FEB, 0xFF238636, 0xFF8957E5, 0xFFDA3633, 0xFFBF8700};
        return colors[Math.abs(id.hashCode()) % colors.length];
    }
}
