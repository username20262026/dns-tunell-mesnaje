package com.dnstunnel;

public class Message {
    public static final int TYPE_SENT     = 0;
    public static final int TYPE_RECEIVED = 1;
    public static final int TYPE_STATUS   = 2;

    public String text;
    public int    type;
    public long   timestamp;

    public Message(String text, int type) {
        this.text      = text;
        this.type      = type;
        this.timestamp = System.currentTimeMillis();
    }
}
