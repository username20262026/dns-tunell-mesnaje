package com.dnstunnel;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Singleton en memoria que guarda todos los chats de la sesión.
 */
public class ChatStore {

    public static class Chat {
        public String       peerId;
        public List<Message> messages = new ArrayList<>();
        public int          unread   = 0;

        public String lastText() {
            if (messages.isEmpty()) return "";
            return messages.get(messages.size() - 1).text;
        }
    }

    private static ChatStore instance;
    // LinkedHashMap mantiene orden de inserción (más reciente al mover)
    private final Map<String, Chat> chats = new LinkedHashMap<>();

    private ChatStore() {}

    public static ChatStore get() {
        if (instance == null) instance = new ChatStore();
        return instance;
    }

    public synchronized Chat getOrCreate(String peerId) {
        if (!chats.containsKey(peerId)) {
            Chat c = new Chat();
            c.peerId = peerId;
            chats.put(peerId, c);
        }
        return chats.get(peerId);
    }

    public synchronized void addMessage(String peerId, Message msg) {
        Chat c = getOrCreate(peerId);
        c.messages.add(msg);
        if (msg.type == Message.TYPE_RECEIVED) c.unread++;
        // Mover al frente (más reciente)
        chats.remove(peerId);
        chats.put(peerId, c);
    }

    public synchronized void clearUnread(String peerId) {
        Chat c = chats.get(peerId);
        if (c != null) c.unread = 0;
    }

    /** Lista de chats ordenados más reciente primero */
    public synchronized List<Chat> getChats() {
        List<Chat> list = new ArrayList<>(chats.values());
        java.util.Collections.reverse(list);
        return list;
    }

    /** Busca chats cuyo peerId contenga la query */
    public synchronized List<Chat> search(String query) {
        List<Chat> result = new ArrayList<>();
        for (Chat c : getChats()) {
            if (c.peerId.contains(query.toLowerCase())) result.add(c);
        }
        return result;
    }
}
