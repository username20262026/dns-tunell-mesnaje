package com.dnstunnel;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Pantalla de chat con un usuario específico.
 */
public class ChatActivity extends Activity {

    public static final String EXTRA_MY_ID   = "my_id";
    public static final String EXTRA_PEER_ID = "peer_id";

    private String myId;
    private String peerId;

    private LinearLayout chatContainer;
    private ScrollView   scrollView;
    private EditText     etMessage;
    private ImageButton  btnSend;
    private TextView     tvStatus;

    private final ExecutorService executor = Executors.newCachedThreadPool();
    private final Handler         handler  = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        myId   = getIntent().getStringExtra(EXTRA_MY_ID);
        peerId = getIntent().getStringExtra(EXTRA_PEER_ID);

        setTitle(peerId);

        // ─── Layout dinámico ──────────────────────────────────────────────
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF0D1117);

        // Status bar
        tvStatus = new TextView(this);
        tvStatus.setText("● Conectando...");
        tvStatus.setTextColor(0xFF8888aa);
        tvStatus.setTextSize(12f);
        tvStatus.setPadding(16, 8, 16, 8);
        root.addView(tvStatus);

        // Chat scroll
        scrollView = new ScrollView(this);
        LinearLayout.LayoutParams scrollParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f);
        scrollView.setLayoutParams(scrollParams);
        chatContainer = new LinearLayout(this);
        chatContainer.setOrientation(LinearLayout.VERTICAL);
        chatContainer.setPadding(8, 8, 8, 8);
        scrollView.addView(chatContainer);
        root.addView(scrollView);

        // Input bar
        LinearLayout inputBar = new LinearLayout(this);
        inputBar.setOrientation(LinearLayout.HORIZONTAL);
        inputBar.setBackgroundColor(0xFF161B22);
        inputBar.setPadding(8, 8, 8, 8);

        etMessage = new EditText(this);
        etMessage.setHint("Mensaje...");
        etMessage.setHintTextColor(0xFF555577);
        etMessage.setTextColor(Color.WHITE);
        etMessage.setBackgroundColor(0xFF21262D);
        etMessage.setPadding(16, 12, 16, 12);
        LinearLayout.LayoutParams etParams = new LinearLayout.LayoutParams(0,
            LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        etMessage.setLayoutParams(etParams);

        btnSend = new ImageButton(this);
        btnSend.setImageResource(android.R.drawable.ic_menu_send);
        btnSend.setBackgroundColor(0xFF238636);
        btnSend.setPadding(24, 12, 24, 12);
        LinearLayout.LayoutParams btnParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT);
        btnParams.leftMargin = 8;
        btnSend.setLayoutParams(btnParams);

        inputBar.addView(etMessage);
        inputBar.addView(btnSend);
        root.addView(inputBar);

        setContentView(root);

        // ─── Cargar historial ─────────────────────────────────────────────
        ChatStore.Chat chat = ChatStore.get().getOrCreate(peerId);
        ChatStore.get().clearUnread(peerId);
        for (Message m : chat.messages) renderBubble(m);

        // ─── Listeners ────────────────────────────────────────────────────
        btnSend.setOnClickListener(v -> trySend());
        etMessage.setOnEditorActionListener((v, id, ev) -> { trySend(); return true; });
    }

    @Override
    protected void onResume() {
        super.onResume();
        ChatStore.get().clearUnread(peerId);
        // Registrar esta activity para recibir mensajes en tiempo real
        MainActivity.activeChatPeer = peerId;
        MainActivity.activeChatActivity = this;
    }

    @Override
    protected void onPause() {
        super.onPause();
        MainActivity.activeChatPeer    = null;
        MainActivity.activeChatActivity = null;
    }

    // ─── Recibir mensaje en tiempo real ──────────────────────────────────────

    public void onNewMessage(Message msg) {
        handler.post(() -> {
            renderBubble(msg);
            ChatStore.get().clearUnread(peerId);
        });
    }

    // ─── Envío ────────────────────────────────────────────────────────────────

    private void trySend() {
        String text = etMessage.getText().toString().trim();
        if (text.isEmpty()) return;
        etMessage.setText("");
        Message msg = new Message(text, Message.TYPE_SENT);
        ChatStore.get().addMessage(peerId, msg);
        renderBubble(msg);
        executor.execute(() -> {
            try {
                boolean ok = DnsClient.sendMessage(myId, peerId, text, (done, total) -> {
                    handler.post(() -> tvStatus.setText("Enviando " + done + "/" + total + "..."));
                });
                handler.post(() -> {
                    Message status = new Message(ok ? "✓ Enviado" : "⚠ Error al enviar",
                        Message.TYPE_STATUS);
                    ChatStore.get().addMessage(peerId, status);
                    renderBubble(status);
                    tvStatus.setText("● Online — " + myId);
                });
            } catch (Exception e) {
                handler.post(() -> renderBubble(
                    new Message("Error: " + e.getMessage(), Message.TYPE_STATUS)));
            }
        });
    }

    // ─── UI ──────────────────────────────────────────────────────────────────

    private void renderBubble(Message msg) {
        handler.post(() -> {
            TextView tv = new TextView(this);
            tv.setText(msg.text);
            tv.setTextSize(15f);
            tv.setPadding(20, 10, 20, 10);

            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
            p.topMargin = 4; p.bottomMargin = 4;

            switch (msg.type) {
                case Message.TYPE_SENT:
                    tv.setTextColor(Color.WHITE);
                    tv.setBackgroundResource(R.drawable.bg_bubble_sent);
                    p.gravity = Gravity.END;
                    p.leftMargin = 64; p.rightMargin = 12;
                    break;
                case Message.TYPE_RECEIVED:
                    tv.setTextColor(Color.WHITE);
                    tv.setBackgroundResource(R.drawable.bg_bubble_received);
                    p.gravity = Gravity.START;
                    p.leftMargin = 12; p.rightMargin = 64;
                    break;
                case Message.TYPE_STATUS:
                    tv.setTextColor(0xFF8888aa);
                    tv.setTextSize(12f);
                    tv.setBackgroundResource(R.drawable.bg_bubble_status);
                    p.gravity = Gravity.CENTER_HORIZONTAL;
                    p.leftMargin = 32; p.rightMargin = 32;
                    break;
            }
            tv.setLayoutParams(p);
            chatContainer.addView(tv);
            scrollView.post(() -> scrollView.fullScroll(ScrollView.FOCUS_DOWN));
        });
    }

    public void setOnlineStatus(boolean online) {
        handler.post(() -> {
            tvStatus.setText(online ? "● Online — " + myId : "● Sin conexión");
            tvStatus.setTextColor(online ? 0xFF44cc77 : 0xFFcc4444);
        });
    }
}
