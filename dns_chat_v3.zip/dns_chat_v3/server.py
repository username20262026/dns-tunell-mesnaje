import socketserver
import sqlite3
import base64
import threading
from dnslib import DNSRecord, RR, QTYPE, A, TXT

DOMAIN_SUFFIX = ".t.nnxsw-proyect.date."
DB_PATH = "C:/Users/Juan/Downloads/dns_chat_v3/messages.db"

def init_db():
    conn = sqlite3.connect(DB_PATH)
    conn.execute("""CREATE TABLE IF NOT EXISTS inbox (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        from_user TEXT,
        to_user TEXT,
        message TEXT,
        delivered INTEGER DEFAULT 0,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
    )""")
    conn.execute("""CREATE TABLE IF NOT EXISTS chunks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id TEXT,
        seq INTEGER,
        total INTEGER,
        chunk TEXT,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
    )""")
    conn.commit()
    conn.close()

def decode_b32(b32_string):
    try:
        b32_string = b32_string.upper()
        b32_string += "=" * ((8 - len(b32_string) % 8) % 8)
        return base64.b32decode(b32_string).decode("utf-8", errors="replace")
    except:
        return ""

def encode_b32(text):
    return base64.b32encode(text.encode("utf-8")).decode().rstrip("=").lower()

def save_chunk(user_id, seq, total, chunk_text):
    conn = sqlite3.connect(DB_PATH)
    conn.execute("INSERT INTO chunks (user_id, seq, total, chunk) VALUES (?, ?, ?, ?)",
        (user_id, int(seq), int(total), chunk_text))
    conn.commit()
    conn.close()

def try_assemble(user_id, total):
    conn = sqlite3.connect(DB_PATH)
    rows = conn.execute(
        "SELECT chunk FROM chunks WHERE user_id=? ORDER BY seq",
        (user_id,)).fetchall()
    conn.close()
    if len(rows) >= int(total):
        full = "".join(r[0] for r in rows)
        clear_chunks(user_id)
        return full
    return None

def clear_chunks(user_id):
    conn = sqlite3.connect(DB_PATH)
    conn.execute("DELETE FROM chunks WHERE user_id=?", (user_id,))
    conn.commit()
    conn.close()

def route_message(from_user, raw_message):
    if raw_message.startswith("to:"):
        parts = raw_message.split(":", 2)
        if len(parts) == 3:
            to_user = parts[1]
            text = parts[2]
            store_message(from_user, to_user, text)
            print(f"[ROUTE] {from_user} -> {to_user}: {text}")
            return
    store_message(from_user, "server", raw_message)
    print(f"[MSG] {from_user}: {raw_message}")

def store_message(from_user, to_user, text):
    conn = sqlite3.connect(DB_PATH)
    conn.execute("INSERT INTO inbox (from_user, to_user, message) VALUES (?, ?, ?)",
        (from_user, to_user, text))
    conn.commit()
    conn.close()

def get_pending(user_id):
    conn = sqlite3.connect(DB_PATH)
    row = conn.execute(
        "SELECT id, from_user, message FROM inbox WHERE to_user=? AND delivered=0 ORDER BY id LIMIT 1",
        (user_id,)).fetchone()
    conn.close()
    return row

def mark_delivered(msg_id):
    conn = sqlite3.connect(DB_PATH)
    conn.execute("UPDATE inbox SET delivered=1 WHERE id=?", (msg_id,))
    conn.commit()
    conn.close()

def queue_from_console(to_user, text):
    store_message("server", to_user, text)
    print(f"[CONSOLE] server -> {to_user}: {text}")

def list_users():
    conn = sqlite3.connect(DB_PATH)
    rows = conn.execute(
        "SELECT DISTINCT from_user FROM chunks UNION SELECT DISTINCT from_user FROM inbox ORDER BY 1"
    ).fetchall()
    conn.close()
    users = [r[0] for r in rows if r[0] != "server"]
    print("[USERS] " + (", ".join(users) if users else "ninguno"))

class DNSHandler(socketserver.BaseRequestHandler):
    def handle(self):
        data, sock = self.request
        try:
            req = DNSRecord.parse(data)
            qname = str(req.q.qname)
            reply = req.reply()

            if not qname.endswith(DOMAIN_SUFFIX):
                reply.header.rcode = 3
                sock.sendto(reply.pack(), self.client_address)
                return

            sub = qname[:-len(DOMAIN_SUFFIX)]
            parts = sub.split(".", 3)

            if parts[0] == "poll" and len(parts) >= 2:
                user_id = parts[1]
                pending = get_pending(user_id)
                if pending:
                    msg_id, from_user, message = pending
                    payload_text = from_user + "|" + message
                    encoded = encode_b32(payload_text)
                    chunks = [encoded[i:i+20] for i in range(0, len(encoded), 20)]
                    total = len(chunks)
                    payload = str(total) + "|" + "|".join(chunks)
                    reply.add_answer(RR(req.q.qname, QTYPE.TXT,
                        rdata=TXT(payload.encode()), ttl=0))
                    mark_delivered(msg_id)
                    print(f"[SEND] {from_user} -> {user_id}: {message}")
                else:
                    reply.add_answer(RR(req.q.qname, QTYPE.TXT,
                        rdata=TXT(b"empty"), ttl=0))

            elif len(parts) == 4:
                uid, seq, total, payload = parts
                text = decode_b32(payload)
                save_chunk(uid, seq, total, text)
                print(f"[CHUNK] {uid} {seq}/{total}: {text}")
                assembled = try_assemble(uid, total)
                if assembled:
                    route_message(uid, assembled)
                ack = "10." + str(int(seq)) + "." + str(int(total)) + ".1"
                reply.add_answer(RR(req.q.qname, QTYPE.A, rdata=A(ack), ttl=0))
            else:
                reply.add_answer(RR(req.q.qname, QTYPE.A, rdata=A("10.0.0.0"), ttl=0))

            sock.sendto(reply.pack(), self.client_address)
        except Exception as e:
            print(f"[ERROR] {e}")

class DNSServer(socketserver.ThreadingMixIn, socketserver.UDPServer):
    allow_reuse_address = True

def console_input():
    def _run():
        print("Servidor listo. Comandos:")
        print("  send:<usuario>:<mensaje>  → enviar mensaje a un usuario")
        print("  users                     → listar usuarios activos")
        print("  broadcast:<mensaje>       → enviar a todos los usuarios activos")
        while True:
            try:
                line = input()
                if line.startswith("send:"):
                    parts = line.split(":", 2)
                    if len(parts) == 3:
                        queue_from_console(parts[1], parts[2])
                elif line.strip() == "users":
                    list_users()
                elif line.startswith("broadcast:"):
                    msg = line.split(":", 1)[1]
                    conn = sqlite3.connect(DB_PATH)
                    users = conn.execute(
                        "SELECT DISTINCT from_user FROM chunks UNION SELECT DISTINCT from_user FROM inbox"
                    ).fetchall()
                    conn.close()
                    for u in users:
                        if u[0] != "server":
                            queue_from_console(u[0], msg)
            except:
                break
    threading.Thread(target=_run, daemon=True).start()

if __name__ == "__main__":
    init_db()
    console_input()
    print("Servidor DNS multiusuario escuchando en 0.0.0.0:53...")
    print("Dominio: *.t.nnxsw-proyect.date")
    server = DNSServer(("0.0.0.0", 53), DNSHandler)
    server.serve_forever()